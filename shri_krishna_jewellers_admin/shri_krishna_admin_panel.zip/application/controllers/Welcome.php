<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Welcome extends CI_Controller {
        public function __construct() {
            parent::__construct();
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->library('session');
            $this->load->model('welcome_model');
            $this->load->library('upload');
        }

        public function index()
        {
            $this->load->view('vw_login');
        }

        public function process()
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('user_name','Username','required');
            $this->form_validation->set_rules('password','Password','required');
            if($this->form_validation->run())
            {
                $user_name = $this->input->post('user_name');
                $password = $this->input->post('password');
                $encrypted_password = sha1($password);

                if($this->welcome_model->validate($user_name,$encrypted_password))
                {
                    date_default_timezone_set("Asia/Calcutta");
                    $todays_date = date('Y-m-d');

                    $this->db->select('*');
                    $this->db->from('user_login');
                    $where = '(user_name = "'.$user_name.'" AND password = "'.$encrypted_password.'")';
                    $this->db->where($where);
                    $user_master = $this->db->get();
                    $row = $user_master->row();
                    $session_owner = 1;

                    $role_id = $row->role_id;

                    if(!empty($row))
                    {
                        $session_data = array('user_name' => $user_name ,'user_id' => $row->entity_id,
                            'full_name' => $row->full_name , 'company_name' => $row->company_name , 'gst_status' => $row->gst_applicable, 'session_owner' => $session_owner, 'role_id' => $role_id);
                        $this->session->set_userdata($session_data);
                        redirect(base_url().'vw_erp_product_master');
                    }else{
                        $this->session->set_flashdata('error','Invalid Username And Password');
                        redirect(base_url().'welcome');
                    }
                }
                elseif($this->welcome_model->validate_new($user_name,$encrypted_password))
                {
                    date_default_timezone_set("Asia/Calcutta");
                    $todays_date = date('Y-m-d');

                    $this->db->select('*');
                    $this->db->from('employee_master');
                    $where = '(user_name = "'.$user_name.'" AND password = "'.$encrypted_password.'")';
                    $this->db->where($where);
                    $employee_master = $this->db->get();
                    $employee_master_data = $employee_master->row();

                    $user_name = $employee_master_data->user_name;
                    $role_type = $employee_master_data->role_type;

                    $user_id = $employee_master_data->user_id;
                    $emp_first_name = $employee_master_data->emp_first_name;
                    $emp_middle_name = $employee_master_data->emp_middle_name;
                    $emp_last_name = $employee_master_data->emp_last_name;
                    // $full_name = $emp_first_name.' '.$emp_middle_name.' '.$emp_last_name;
                    $role_id = $employee_master_data->role_id;
                    $full_name = $employee_master_data->full_name;
                    // print_r($full_name);
                    // die();

                    $this->db->select('*');
                    $this->db->from('user_login');
                    $where = '(entity_id = "'.$user_id.'")';
                    $this->db->where($where);
                    $user_login = $this->db->get();
                    $user_login_data = $user_login->row();
                    $company_name = $user_login_data->company_name;
                    $gst_applicable = $user_login_data->gst_applicable;

                    $session_owner = 2;



                    if(!empty($employee_master_data))
                    {
                        $session_data = array('user_name' => $user_name ,'user_id' => $user_id,
                            'full_name' => $full_name , 'company_name' => $company_name , 'gst_status' => $gst_applicable, 'session_owner' => $session_owner, 'role_type' => $role_type, 'role_id' => $role_id, 'full_name' => $full_name);
                        $this->session->set_userdata($session_data);
                        redirect(base_url().'dashboard');
                    }else{
                        $this->session->set_flashdata('error','Invalid Username And Password');
                        redirect(base_url().'welcome');
                    }
                }
                else{
                    $this->session->set_flashdata('error','Invalid Username And Password');
                    redirect(base_url().'welcome');
                }
            }else{
                $this->session->set_flashdata('error','Enter Username And Password');
                redirect(base_url().'welcome');
            }      
        }

        public function dashboard()
        {
            if($this->session->userdata('user_name') != '')  
            {  
                $this->load->view('welcome_message');
            }  
            else{  
                redirect(base_url().'welcome');
            }
        }

        public function login()  
        {  
            $this->load->view('welcome_message');
        }

        public function logout()
        {
            $this->session->unset_userdata('username');
            $this->session->sess_destroy();
            redirect('welcome');
        }

        public function crop_drawing_page()
        {
            $data['cropping_data'] = $this->welcome_model->get_crop_attachment();

            $this->load->view('crop_drawing_page',$data);
        }

        public function create_new_crop_image()
        {
            $this->load->view('crop_machine_page');
        }
    }
?>
