<footer class="main-footer">
    <strong>Copyright &copy; 2020-2021 <a target="_blank" href="https://www.vbdigitech.com/">VB Digitech</a>.</strong>
    All rights reserved.


    
  </footer>

  